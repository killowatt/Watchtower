// Copyright 2017 William Yates

#include "Watchtower.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Watchtower, "Watchtower" );
